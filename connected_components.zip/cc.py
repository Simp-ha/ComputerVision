import cv2
import numpy as np

def imshow_components(labels):
    # Map component labels to hue val
    label_hue = np.uint8(179*labels/np.max(labels))
    blank_ch = 255*np.ones_like(label_hue)
    labeled_img = cv2.merge([label_hue, blank_ch, blank_ch])

    # cvt to BGR for display
    labeled_img = cv2.cvtColor(labeled_img, cv2.COLOR_HSV2BGR)

    # set bg label to black
    labeled_img[label_hue==0] = 0

    cv2.namedWindow('labeled', cv2.WINDOW_NORMAL)
    cv2.imshow('labeled', labeled_img)

img = cv2.imread('cells.png', cv2.IMREAD_GRAYSCALE)
_, img = cv2.threshold(img, 100, 255, cv2.THRESH_BINARY)


"""
https://stackoverflow.com/questions/35854197/how-to-use-opencvs-connectedcomponentswithstats-in-python

num_cc : Number of detected connected components.

labeled : A matrix the size of the input image where each element has a value equal to its label.

stats : A matrix of the stats that the function calculates. It has a length equal to the number of labels and a width equal to the number of stats. 
        Statistics are accessed via stats[label, COLUMN] where available columns are defined below.

        cv2.CC_STAT_LEFT : Leftmost (x) coordinate which is the inclusive start of the bounding box in the horizontal direction.
        cv2.CC_STAT_TOP : Topmost (y) coordinate which is the inclusive start of the bounding box in the vertical direction.
        cv2.CC_STAT_WIDTH : The horizontal size of the bounding box
        cv2.CC_STAT_HEIGHT : The vertical size of the bounding box
        cv2.CC_STAT_AREA : The total area (in pixels) of the connected component
        
centroids : A matrix with the x and y locations of each centroid. The row in this matrix corresponds to the label number.
"""

# num_cc, labeled = cv2.connectedComponents(img)
num_cc, labeled, stats, centroids = cv2.connectedComponentsWithStats(img)

imshow_components(labeled)

cv2.waitKey(0)